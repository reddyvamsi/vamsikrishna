export class Project {
    userId:any;
    id:any;
    title:any;
    body:any;
    constructor(){
        this.userId=0;
        this.id=0;
        this.title=null;
        this.body=null;
    }
}
