import { Component, OnInit} from '@angular/core';
import { DatashareService} from "../app/datashare.service";
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angularproject';
  public today = new Date()
  public wishforuser:string="";
  public Username:string='';
    constructor(){
      setInterval(()=>{
        this.today=new Date();
        this.today.getHours();
        // console.log( typeof this.Today.getHours());
        if(this.today.getHours()<12){
          this.wishforuser="Good Morning";
          // console.log("test1");
        }else if(this.today.getHours()>=12 && this.today.getHours()<18){
              this.wishforuser="Good Afternoon"
              // alert("2")
        }else if(this.today.getHours()>=18){
          this.wishforuser="Good Evening"
          // alert("3")
        }
       
        // if(this.Today.getHours()<12){
        //   this.wishforuser="Good Morning";
        // } if(this.Today.getHours()==12 && this.Today.getHours()<18 ){
        //   this.wishforuser="Good Afternoon"
        // }if(this.Today.getHours()>=18){
        //   this.wishforuser="Good Evening"
        //   alert("3")
        // }
          },1000);
    }
  
  ngOnInit() {
    this.Username="Vamsikrishna";
  }
}
