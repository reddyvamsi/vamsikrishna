import { Injectable } from '@angular/core';

@Injectable()//--->removing the service for the root level

// @Injectable({
//   providedIn:'root'   --> this is for root level of the service  we can  acces any where in application
// })
export class DashboardService {

  constructor() { }
  getteamsummary():any[]
  {
   let Teammemberssummary=[
    {Region:'East', Teammemberscount:20, TemporarilyUnavailableMembers:4},
    {Region:'west', Teammemberscount:15, TemporarilyUnavailableMembers:8},
    {Region:'south', Teammemberscount:17, TemporarilyUnavailableMembers:1},
    {Region:'North', Teammemberscount:15, TemporarilyUnavailableMembers:6}
    ];
    return Teammemberssummary
  }
}
