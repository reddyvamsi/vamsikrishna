import { formatCurrency } from '@angular/common';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {DashboardService} from '../../dashboard.service'
import { DatashareService } from 'src/app/datashare.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public Designation:string='';
  public Username:string='';
  public NoOfTeamMembers:number=0;
  public TotalCostOfAllProjects:number=0;
  public PendingTasks:number=0;
  public UpComingProjects:number=0;
  public ProjectCost:number=0;
   public CurrentExpenditure:number=0;
   public AvaliableFunds:number=0;
  //  public today!: Date;
      public today = new Date()
    public wishforuser:string="";
   // create array for projects
   public time:number=0
 projects:string[]=[];         
Clients:string[]=[];
Years:number[]=[];
Teammemberssummary:any=[];
teammembersgroup:any=[];

  constructor(private dashboardservice:DashboardService) {
    setInterval(()=>{
      this.today=new Date();
      this.today.getHours();
      // console.log( typeof this.Today.getHours());
      if(this.today.getHours()<12){
        this.wishforuser="Good Morning";
        // console.log("test1");
      }else if(this.today.getHours()>=12 && this.today.getHours()<=18){
            this.wishforuser="Good Afternoon"
            // alert("2")
      }else if(this.today.getHours()>18){
        this.wishforuser="Good Evening"
        // alert("3")
      }
      // if(this.Today.getHours()<12){
      //   this.wishforuser="Good Morning";
      // } if(this.Today.getHours()==12 && this.Today.getHours()<18 ){
      //   this.wishforuser="Good Afternoon"
      // }if(this.Today.getHours()>=18){
      //   this.wishforuser="Good Evening"
      //   alert("3")
      // }
        },1000);
   }
   

  ngOnInit(): void {
    this.Designation="Team Lead";

    this.NoOfTeamMembers=5;
    this.TotalCostOfAllProjects=345;
    this.PendingTasks=3;
    this.UpComingProjects=5;
    this.ProjectCost=4786;
    this.CurrentExpenditure=342;
    this.AvaliableFunds=43;

    this.projects=["project A","project B","project C","project D"];
    this.Clients=["ABC Infotech Ltd","DEF Software Solutions", "GHI Industries"];
    this.Years=[2019,2018,2017,2016];

    //team membersummary service cal is here

     this.Teammemberssummary=this.dashboardservice.getteamsummary();
    this.teammembersgroup=[
      {
        region:"East", members:[
          {
         ID:1, Name:"krishna", statues:"available"},
         {ID:2, Name:"ravi", statues:"available"},
         {ID:3, Name:"krishna", statues:"available"},
         {ID:4, Name:"krishna", statues:"available"},
      ]
    },
      {
        region:"South", members:[{
        ID:5, Name:"varma", statues:"available"},
        {ID:6, Name:"kavya", statues:"available"},
        {ID:7, Name:"krishna", statues:"notavailble"},
        {ID:8, Name:"dhoni", statues:"available"},
     ]
    },
     {region:"West", members:[{
      ID:9, Name:"rahul", statues:"avaliable"},
      {ID:10, Name:"kohli", statues:"notavailble"},
      {ID:11, Name:"gill", statues:"notavailble"},
      {ID:12, Name:"ashwin", statues:"avaliable"},
   ]},
   {region:"North", members:[
     {
    ID:13, Name:"rohith", statues:"avaliable"},
    {ID:14, Name:"dhawan", statues:"notavailble"},
    {ID:15, Name:"murali", statues:"notavailble"},
    {ID:16, Name:"yamuna", statues:"avaliable"},
 ]}
    ];
    //console.log(this.teammembersgroup);
     
  
  }
  getprojects($event:any){
    console.log($event.target.innerHTML)
    if($event.target.innerHTML==="project A"){
      this.ProjectCost=4786;
    this.CurrentExpenditure=342;
    this.AvaliableFunds=43;
    }else if($event.target.innerHTML==="project B"){
      this.ProjectCost=5646;
      this.CurrentExpenditure=6742;
      this.AvaliableFunds=785;
    }else if($event.target.innerHTML==="project C"){
      this.ProjectCost=7564;
      this.CurrentExpenditure=5475;
      this.AvaliableFunds=755;
    }else if($event.target.innerHTML==="project D"){
      this.ProjectCost=4645;
      this.CurrentExpenditure=5464;
      this.AvaliableFunds=345;
    }
  }
 
}
