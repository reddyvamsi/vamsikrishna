import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cal',
  templateUrl: './cal.component.html',
  styleUrls: ['./cal.component.scss']
})
export class CalComponent implements OnInit {

  title:string="calculate number";
  counter:number=0;
  constructor() { }

  ngOnInit(): void {
  }
increment=()=>{
  this.counter=this.counter+1;
  if(this.counter === 10){
   this.counter = this.counter+15;
};
}
decrement=()=>{
  this.counter=this.counter-1;
  if(this.counter ==-1){
   this.counter = this.counter=0;
  }
}
reset=()=>{
this.counter=0;
}
}
