import { Component, OnInit } from '@angular/core';
import arrayofwords from './words'; 
@Component({
  selector: 'app-wordgen',
  templateUrl: './wordgen.component.html',
  styleUrls: ['./wordgen.component.scss']
})
export class WordgenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  usname:string="";
title:string="words limit";
valueofrand:number=10;
listofcu:any=""
countrylimit=10;
words:string="";
limit:any=10;
countrylist:any=["ind","usa","chan","pak", "rash"];
selctavule(newLimit:any){
  this.limit=newLimit.target.value;
}
showthewords(){
  this.words=arrayofwords.slice(0,this.limit).join(" ");
  console.log("test");
}

getcountry(){
this.valueofrand=Math.floor(Math.random()*this.countrylist.length);
this.listofcu=this.countrylist[this.valueofrand];
console.log("test")
}
sel(event:any){
 this.usname=event.target.value;
}
sho(value:any){
  this.usname=value;
 console.log(this.usname);
}
}


