export default[
    "busy",
    "vamsi",
    "reddy",
    "krishna",
    "hai",
    "all",
    "how are you",
    "fine",
    "right",
    "thank you"
]