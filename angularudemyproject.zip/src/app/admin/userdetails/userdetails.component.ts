import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { RouterModule, Router  } from '@angular/router';
@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss']
})
export class UserdetailsComponent implements OnInit {
      number=0;
      // public userdetailsForm:FormGroup;
     
      UserName:String="";   
      password:String="";
  constructor(private route:Router) {
    // this.userdetailsForm=new FormGroup({
    //   UserName:new FormControl(),
    //   password:new FormControl()

    // });
    
   }
  ngOnInit(): void {
    
  }
  details():void{
    alert("s1")
    if(this.UserName == "vamsi" && this.password == "krishna"){
      // console.log(this.userdetailsForm.value);
      console.log(this.UserName);
      this.route.navigate(['dashboard']);
    }else{
      alert("your Username and Password is wrong");
    }
   

  }
  incr(){
    this.number++;
    console.log(this.number);
  }

}
