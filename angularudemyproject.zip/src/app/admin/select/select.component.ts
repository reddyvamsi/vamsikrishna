import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit {
  
  names = [
    {  name: 'Dr Nice' },
    {  name: 'Narco' },
    {  name: 'Bombasto' },
    {  name: 'Celeritas' },
    {  name: 'Magneta' },
    {  name: 'RubberMan' },
    {  name: 'Dynama' },
    {  name: 'Dr IQ' },
    {  name: 'Magma' },
    {  name: 'Tornado' }
  ];
  constructor() { }

  ngOnInit(): void {
  
  }
  selectChange() {
     console.log(this.names);
  }
 
}
