import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from '../app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import {DashboardComponent} from './dashboard//dashboard.component';
import {AboutComponent} from './about/about.component';
import { ProjectsComponent} from "./projects/projects.component"
import {MyprofileComponent} from './myprofile/myprofile.component';
import {DashboardService} from "../dashboard.service";
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { SelectComponent } from './select/select.component';
import { CalComponent } from './cal/cal.component';
import { WordgenComponent } from './wordgen/wordgen.component';


@NgModule({
  declarations: [
    DashboardComponent,
    AboutComponent,
    MyprofileComponent,
    ProjectsComponent,
    UserdetailsComponent,
    SelectComponent,
    CalComponent,
    WordgenComponent,
   
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers:[DashboardService],
  exports:[DashboardComponent, AboutComponent,MyprofileComponent,ProjectsComponent, UserdetailsComponent ]
})
export class AdminModule { }
