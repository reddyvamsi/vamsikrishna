import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserdetailsComponent} from "./admin/userdetails/userdetails.component";
import {DashboardComponent} from "./admin/dashboard/dashboard.component";
import {AboutComponent}from "./admin/about/about.component";
import {ProjectsComponent} from "./admin/projects/projects.component";
import {SelectComponent}from "./admin/select/select.component";
import { CalComponent } from './admin/cal/cal.component';
import { WordgenComponent } from './admin/wordgen/wordgen.component';
const routes: Routes = [
  {path:"login", component:UserdetailsComponent},
  {path:"dashboard", component:DashboardComponent},
  {path:"about", component:AboutComponent},
  {path:"select", component :SelectComponent},
  {path:"projects", component:ProjectsComponent},
  {path:"cal", component:CalComponent},
  {path:"wordgen",component:WordgenComponent},
  {path:"", redirectTo:"login", pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
